// "Simple.c"
// Ce programme simple permet de tester les p�riph�riques de votre syst�me
// en lisant les diff�rentes entr�es et en �crivant sur les diff�rentes sorties

#include "system.h"
#include "altera_avalon_pio_regs.h"
#include "unistd.h"
#include "stdio.h"

int main()
{
	int value;

	while (1)
	{
		value = IORD_ALTERA_AVALON_PIO_DATA(SW_BASE);

		printf("Value = %i\r\n", value);

		//IOWR_ALTERA_AVALON_PIO_DATA(IP_SERVOMOTEUR_0_BASE, value);
		IOWR(IP_SERVOMOTEUR_0_BASE, 1, value);

		//Ecriture sur le servomoteur
		//if (value > 0)
		//IOWR_ALTERA_AVALON_PIO_DATA(DE1_SOC_SEVENSEG_0_BASE + 0, ~SevenSeg[value%10]);

		usleep(200000); // tempo de 200 000 �s --> 200 ms
	}


	return 0;
}
