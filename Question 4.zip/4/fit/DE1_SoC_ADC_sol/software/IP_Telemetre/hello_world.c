// "Simple.c"
// Ce programme simple permet de tester les p�riph�riques de votre syst�me
// en lisant les diff�rentes entr�es et en �crivant sur les diff�rentes sorties

#include "system.h"
#include "altera_avalon_pio_regs.h"
#include "unistd.h"
#include "stdio.h"

int main() {
  int value;
  int degree = 0;
  int sens = 0;
  unsigned int SevenSeg[10] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0xED, 0xFD, 0x07, 0xFF, 0xEF};

  //Envoyer un message sur la sortie s�rie standard (Jtag ou RS232)
  //printf("Hello World !\n");

	while (1)
	{
		//Lecture sur le telemetre
		//int value = IORD_ALTERA_AVALON_PIO_DATA(HC_SR04_0_BASE);
		value = IORD_ALTERA_AVALON_PIO_DATA(HC_SR04_0_BASE);
		IOWR_8DIRECT(IP_SERVOMOTEUR_0_BASE, 0, degree);

		printf("%i� -> %i cm\r\n", degree, value);

		//Ecriture sur les afficheurs 7 segments
		if (value > 0)
			IOWR_ALTERA_AVALON_PIO_DATA(DE1_SOC_SEVENSEG_0_BASE + 0, ~SevenSeg[value%10]);
		else
			IOWR_ALTERA_AVALON_PIO_DATA(DE1_SOC_SEVENSEG_0_BASE + 0, ~SevenSeg[0]);
		if (value > 9)
			IOWR_ALTERA_AVALON_PIO_DATA(DE1_SOC_SEVENSEG_0_BASE + 4, ~SevenSeg[(value%100)/10]);
		else
			IOWR_ALTERA_AVALON_PIO_DATA(DE1_SOC_SEVENSEG_0_BASE + 4, ~SevenSeg[0]);

		if (value > 99)
			IOWR_ALTERA_AVALON_PIO_DATA(DE1_SOC_SEVENSEG_0_BASE + 8, ~SevenSeg[(value%1000)/100]);
		else
			IOWR_ALTERA_AVALON_PIO_DATA(DE1_SOC_SEVENSEG_0_BASE + 8, ~SevenSeg[0]);

		if (value > 999)
			IOWR_ALTERA_AVALON_PIO_DATA(DE1_SOC_SEVENSEG_0_BASE + 12, ~SevenSeg[(value%10000)/1000]);
		else
			IOWR_ALTERA_AVALON_PIO_DATA(DE1_SOC_SEVENSEG_0_BASE + 12, ~SevenSeg[0]);

		if (value > 9999)
			IOWR_ALTERA_AVALON_PIO_DATA(DE1_SOC_SEVENSEG_0_BASE + 16, ~SevenSeg[(value%100000)/10000] );
		else
			IOWR_ALTERA_AVALON_PIO_DATA(DE1_SOC_SEVENSEG_0_BASE + 16, ~SevenSeg[0]);

		if (value > 99999)
			IOWR_ALTERA_AVALON_PIO_DATA(DE1_SOC_SEVENSEG_0_BASE + 20, ~SevenSeg[(value%1000000)/100000] );
		else
			IOWR_ALTERA_AVALON_PIO_DATA(DE1_SOC_SEVENSEG_0_BASE + 20, ~SevenSeg[0]);

		if (!sens)
			degree++;
		else
			degree--;

		if (degree == 180)
		{
			degree = 179;
			sens = 1;
		}

		if (degree == 0)
		{
			degree = 1;
			sens = 0;
		}

		usleep(20000); // tempo de 20 000 �s --> 20 ms
	}
	return 0;
}
